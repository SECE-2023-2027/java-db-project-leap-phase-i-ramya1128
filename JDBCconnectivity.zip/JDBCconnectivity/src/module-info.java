module JDBCconnectivity {
	requires java.sql;
}