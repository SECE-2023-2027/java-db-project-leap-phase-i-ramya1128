package JDBCconnectivity;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;

public class Main {
	public static void main(String[] args)throws SQLException {
		String url="jdbc:mysql://localhost:3306/sample";
		String username="root";
		String password="MySQL@Ramya11";
		
		Connection con=DriverManager.getConnection(url,username, password);
		if(con!=null) {
			System.out.println("Connection Established");
		}
		else {
			System.out.println("Connection Not Established");
		}
		
		Scanner sc=new Scanner(System.in);
		
		
		//create
		System.out.println("Enter User Details");
		String name1=sc.nextLine();
		String pass1=sc.nextLine();
		int id1=sc.nextInt();
		String sql="Insert into users(username,password,user_id)" + "values(?,?,?)";
		PreparedStatement ps1=con.prepareStatement(sql);
		ps1.setString(1, name1);
		ps1.setString(2, pass1);
		ps1.setInt(3, id1);
		int res1=ps1.executeUpdate();
		if(res1>0) {
			System.out.println("A new user created!");
		}
		
		String query1="select * from users";
		Statement st1=con.createStatement();
		ResultSet rs1=st1.executeQuery(query1);
		while(rs1.next()) {
			System.out.println("UserName:"+rs1.getString("username"));
			System.out.println("PassWord:"+rs1.getString("password"));
			System.out.println("User ID:"+rs1.getString("user_Id"));
		}
		
		
		//update
		System.out.println("Enter the values to be updated");
	    String name2=sc.nextLine();
	    String pass2=sc.nextLine();
	    int id2=sc.nextInt();
	    String Updatequery="update users set username=?,password=? where user_id=? ";
	    PreparedStatement ps2=con.prepareStatement(Updatequery);
	    ps2.setString(1, name2);
	    ps2.setString(2, pass2);
	    ps2.setInt(3, id2);
	    int updateRes=ps2.executeUpdate();
	    if(updateRes>0) {
	    	System.out.println("User details updated successfully!!");
	    }
	    else {
	    	System.out.println("No user is found ");
	    }
	    String query2="select * from users";
		Statement st2=con.createStatement();
		ResultSet rs2=st2.executeQuery(query2);
		while(rs2.next()) {
			System.out.println("UserName:"+rs2.getString("username"));
			System.out.println("PassWord:"+rs2.getString("password"));
			System.out.println("User ID:"+rs2.getString("user_Id"));
		}
		
		
	    
	    //delete 
	    System.out.println("Enter the user id to be deleted");
	    int id3=sc.nextInt();
	    String deleteQuery="delete from users where user_id=?";
	    PreparedStatement ps3=con.prepareStatement(deleteQuery);
	    ps3.setInt(1, id3);
	    int delRes=ps3.executeUpdate();
	    if(delRes>0) {
	    	System.out.println("User deleted Successfully!!");
	    }
	    else {
	    	System.out.println("Invalid userid!!");
	    }
	    
	    
	    //view
	    System.out.println("Enter the user ID:");
	    int id31 = sc.nextInt();
	    // Prepare the SQL query
	    String selectQuery = "SELECT username, password, user_id FROM users WHERE user_id = ?";
	    PreparedStatement ps31 = con.prepareStatement(selectQuery);
	    ps31.setInt(1, id31);  // Set the parameter

	    // Execute the query
	    ResultSet res3 = ps31.executeQuery();  // Do not pass selectQuery again

	    // Process the results
	    if (res3.next()) {
	        System.out.println("Username: " + res3.getString("username"));
	        System.out.println("Password: " + res3.getString("password"));
	        System.out.println("User ID: " + res3.getInt("user_id"));
	    } else {
	        System.out.println("No user found with the given user ID.");
	    }
	}
}
