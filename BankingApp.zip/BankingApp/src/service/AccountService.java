package service;

import java.sql.SQLException;

import exception.AccountnotFoundException;
//import dao.BankDAO;
import exception.InvalidAccountTypeException;
import dao.AccountDAO;
import dao.AccountDAOImpl;
import model.Account;
import model.CurrentAccount;

public class AccountService {
	private final AccountDAO accountDAO;
	
	public AccountService(){
		this.accountDAO = new AccountDAOImpl();   
	}
	
	public void createAccount(Account account) throws SQLException, InvalidAccountTypeException {
		accountDAO.createAccount(account);
	}

	public void updateAccount(Account account) throws SQLException, InvalidAccountTypeException{
		accountDAO.updateAccount(account);
	}
	
	public boolean deleteAccount(int accountId) throws SQLException {
	    return accountDAO.deleteAccount(accountId);
	}
	
	public void viewAccount(int accountId) throws SQLException, InvalidAccountTypeException, AccountnotFoundException{
        accountDAO.viewAccount(accountId);
    }

}
