package service;

import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import dao.TransactionDAO;
import dao.TransactionDAOImpl;
import exception.InvalidTransactionAmountException;
import exception.TransactionFailureException;
import utility.TransactionHistoryUtil;

//import dao.TransactionDAO;

public class TransactionService {
	private final TransactionDAO transactionDAO;
	private final ExecutorService executorService;
	public TransactionService() {
		this.transactionDAO=new TransactionDAOImpl();
		this.executorService=Executors.newFixedThreadPool(5);
	}
	
	public Future<?> deposit(int accountId, double amount)throws SQLException, TransactionFailureException, InvalidTransactionAmountException {
		return executorService.submit(()->{
			try {
				transactionDAO.deposit(accountId, amount);
				TransactionHistoryUtil.saveTransaction("Deposit", accountId, amount);
			}
			catch(TransactionFailureException | InvalidTransactionAmountException e) {
				System.err.println("Error during Deposit: "+e.getMessage());
			}
		});	
	}
	public Future<?> withdraw(int accountId, double amount)throws SQLException, TransactionFailureException, InvalidTransactionAmountException {
		return executorService.submit(()->{
			try {
				transactionDAO.withdraw(accountId, amount);
				TransactionHistoryUtil.saveTransaction("withdraw", accountId, amount);
			}
			catch(TransactionFailureException | InvalidTransactionAmountException | SQLException e) {
				System.err.println("Error during Withdraw: "+e.getMessage());
			}
		});	
	}
	/*public Future<?> withdraw(int accountId,double amount){
		return executorService.submit(()->{
			try {
				transactionDAO.withdraw(accountId, amount);
				TransactionHistoryUtil.saveTransaction("Withdraw", accountId, amount);
			}
			catch(SQLException | TransactionFailureException | InvalidTransactionAmountException | IOException e) {
				System.err.println("Error during withdraw: "+e.getMessage());
			}
		});
	}*/

	public void shutDownExecutorService() {
		executorService.shutdown();
		
	}

}
