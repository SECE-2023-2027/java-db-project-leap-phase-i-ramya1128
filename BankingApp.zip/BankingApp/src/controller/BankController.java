package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import exception.AccountnotFoundException;
import exception.BankingException;
import exception.InvalidAccountTypeException;
import exception.InvalidTransactionAmountException;
import exception.TransactionFailureException;
//import model.Account;
import model.Bank;
import model.CurrentAccount;
import model.SavingsAccount;
import service.AccountService;
import service.BankService;
import service.TransactionService;

public class BankController {
	private final AccountService accountService;
	private final BankService bankService;
	private final TransactionService transactionService;
	private final BufferedReader br;
	
	public BankController() {
		this.accountService=new AccountService();
		this.bankService=new BankService();
		this.transactionService=new TransactionService();
		this.br=new BufferedReader(new InputStreamReader(System.in));
	}
	
	public void start() throws NumberFormatException, IOException, SQLException, BankingException, InvalidAccountTypeException, TransactionFailureException, InvalidTransactionAmountException, InterruptedException, ExecutionException, AccountnotFoundException{
		boolean running=true;
		while(running) {
			displayMenu();
			//System.out.println("Enter the Choice");
			int choice=Integer.parseInt(br.readLine());
			switch(choice) {
			case 1:
				createAccount();
				break;
			case 2:
				Deposit();
				break;
			case 3:
				Withdraw();
				break;
			case 4:
				updateAccount();
				break;
			case 5:
				deleteAccount();
				break;
			case 6:
				viewAccount();
				break;
			case 0:
				running=false;
				transactionService.shutDownExecutorService();
				System.out.println("Exiting the app! Goodbye");
				break;
				
			}
		}
	}

	public void displayMenu() {
		System.out.println("----------Banking Application------------");
		System.out.println("1.Create Account");
		System.out.println("2.Deposit");
		System.out.println("3.Withdraw");
		System.out.println("4.Update Account");
		System.out.println("5.Delete Account");
		System.out.println("6.View Account");
		System.out.println("0.Exit");
		System.out.println("Enter the Choice");
	}
	
	public void createAccount() throws SQLException, IOException, BankingException,InvalidAccountTypeException{
		System.out.println("Enter Customer ID: ");
		int cusId=Integer.parseInt(br.readLine());
		
		System.out.println("Enter Bank ID");
		int bankId=Integer.parseInt(br.readLine());
		
		Bank bank=bankService.getBankById(bankId);
		
		System.out.println("Enter Account Type(Savings/Current): ");
		String accountType=br.readLine();
		
		System.out.println("Enter Initial Balance: ");
		double bal=Double.parseDouble(br.readLine());
		
		if("Savings".equalsIgnoreCase(accountType)) {
			System.out.println("Enter Interset Rate: ");
			double interset=Double.parseDouble(br.readLine());
			accountService.createAccount(new SavingsAccount(0,cusId,bank,accountType,bal,interset));
		}
		
		else if("Current".equalsIgnoreCase(accountType)) {
			System.out.println("Enter OverdraftLimit: ");
			double overdraft=Double.parseDouble(br.readLine());
			accountService.createAccount(new CurrentAccount(0,cusId,bank,accountType,bal,overdraft));
		}
		
		else {
			System.out.println("Invalid Account Type");
		}
		
	}
	//update
	public void updateAccount() throws SQLException, InvalidAccountTypeException, NumberFormatException, IOException, BankingException { 
	    System.out.println("Enter Account ID to update: ");
	    int accountId = Integer.parseInt(br.readLine());

	    System.out.println("Enter the Customer ID:");
	    int custId = Integer.parseInt(br.readLine());

	    System.out.println("Enter Bank ID: ");
	    int bankId = Integer.parseInt(br.readLine());

	    // Fetch bank details using bankService
	    Bank bank = bankService.getBankById(bankId);

	    System.out.println("Enter New Balance: ");
	    double newBalance = Double.parseDouble(br.readLine());

	    System.out.println("Enter Account Type (Savings/Current): ");
	    String accountType = br.readLine();

	    if ("Savings".equalsIgnoreCase(accountType)) {
	        System.out.println("Enter New Interest Rate:");
	        double newInterest = Double.parseDouble(br.readLine());
	        
	        // Creating SavingsAccount instance and updating
	        accountService.updateAccount(new SavingsAccount(accountId, custId, bank, accountType, newBalance, newInterest));
	    } 
	    else if ("Current".equalsIgnoreCase(accountType)) {
	        System.out.println("Enter New Overdraft Limit:");
	        double newOverdraft = Double.parseDouble(br.readLine());
	        
	        // Creating CurrentAccount instance and updating
	        accountService.updateAccount(new CurrentAccount(accountId, custId, bank, accountType, newBalance, newOverdraft));
	    } 
	    else {
	        System.out.println("Invalid Account Type. Please enter 'Savings' or 'Current'.");
	    }
	}
	//delete
	public void deleteAccount() throws SQLException, IOException, BankingException {
	    System.out.println("Enter Account ID to delete: ");
	    int accountId = Integer.parseInt(br.readLine());

	    // Call accountService to delete the account by ID
	    boolean isDeleted = accountService.deleteAccount(accountId);

	    if (isDeleted) {
	        System.out.println("Account deleted successfully.");
	    } else {
	        System.out.println("Account deletion failed. Account ID may not exist.");
	    }
	}
	//view
	public void viewAccount() throws IOException, SQLException, InvalidAccountTypeException, BankingException, AccountnotFoundException{
		System.out.println("Enter the AccountID :");
		int accountId=Integer.parseInt(br.readLine());

		accountService.viewAccount(accountId);
		System.out.println("Account viewed Successfully!");
	 }
	
	//deposit
	public void Deposit() throws IOException,NumberFormatException, SQLException, TransactionFailureException, InvalidTransactionAmountException, InterruptedException, ExecutionException{
		System.out.println("Enter Account ID: ");
		int id=Integer.parseInt(br.readLine());
		System.out.println("Enter Amount to be Deposit: ");
		double amount=Double.parseDouble(br.readLine());
		
		Future<?> future=transactionService.deposit(id, amount);
		future.get();
	}
	
	private void Withdraw() throws SQLException, TransactionFailureException, InvalidTransactionAmountException, InterruptedException, ExecutionException, NumberFormatException, IOException {
		System.out.println("Enter Account ID: ");
		int id=Integer.parseInt(br.readLine());
		System.out.println("Enter Amount to be credited: ");
		double amount=Double.parseDouble(br.readLine());
		
		Future<?> future=transactionService.withdraw(id, amount);
		future.get();
		
		
	}
	/*private void Withdraw() throws NumberFormatException, IOException, InterruptedException, ExecutionException {
		System.out.println("Entre Account iD: ");
		int id=Integer.parseInt(br.readLine());
		System.out.println("Enter the Amount to the credited: ");
		double amount=Double.parseDouble(br.readLine());
		Future<?> future=transactionService.withdraw(id, amount);
		future.get();
	}*/
	
	
	
		
	
	
}
