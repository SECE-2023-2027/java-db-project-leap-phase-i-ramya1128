package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import exception.AccountnotFoundException;
import exception.BankingException;
import exception.InvalidAccountTypeException;
import exception.InvalidTransactionAmountException;
import exception.TransactionFailureException;

public class Main {
	public static void main(String[] args) throws NumberFormatException, SQLException, IOException, BankingException, InvalidAccountTypeException, TransactionFailureException, InvalidTransactionAmountException, InterruptedException, ExecutionException, AccountnotFoundException{
		BankController bc=new BankController();
		bc.start();
	}

}
