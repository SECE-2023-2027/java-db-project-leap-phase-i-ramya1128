module BankingApp {
	requires java.sql;
}