package model;

public class SavingsAccount extends Account {
	private double interestRate;

	public SavingsAccount(int accountId, int customerId, Bank bank, String accountType, double balance,double interestRate) {
		super(accountId, customerId, bank, accountType, balance);
		// TODO Auto-generated constructor stub
		this.interestRate=interestRate;
		
	}
	
	
	public double getInerestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate=interestRate;
	}
	@Override
	public String getAccountDetails() {
		return "Savings class with interest rate +"+this.interestRate;
	}
	@Override
	public String toString() {
		return "SavingsAccount Details: Account Id: "+this.getAccountId()+"Customer Id: "+
	    "Bank: "+this.getBank()+"AccountType: "+this.getAccountType()+
	    "Balance: "+this.getBalance()+"InterestRate: "+this.getInerestRate();
	}
	

}
