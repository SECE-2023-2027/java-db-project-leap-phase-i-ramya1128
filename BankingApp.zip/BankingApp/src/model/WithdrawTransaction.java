package model;

import java.util.Date;

public class WithdrawTransaction extends Transaction {
	private String withdrawMethod;

	public WithdrawTransaction(int transactionId, int accountId, String transactionType, double amount, Date transactionDate,String withdrawMethod) {
		super(transactionId, accountId, transactionType, amount, transactionDate);
		// TODO Auto-generated constructor stub
		this.withdrawMethod=withdrawMethod;
	}

	public String getWithdrawMethod() {
		return withdrawMethod;
	}

	public void setWithdrawMethod(String withdrawMethod) {
		this.withdrawMethod = withdrawMethod;
	}

	@Override
	public String getTransactionDetails() {
		return "transaction type:"+this.withdrawMethod;
	}
	


}
