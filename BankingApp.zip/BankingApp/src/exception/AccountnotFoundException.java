package exception;

public class AccountnotFoundException extends Exception{
	public AccountnotFoundException(String message) {
		super(message);
	}
	

}
