package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exception.AccountnotFoundException;
import exception.InvalidAccountTypeException;
import model.Account;
import utility.DBConnection;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public void createAccount(Account account) throws InvalidAccountTypeException, SQLException {
		String sql="insert into Account(customer_id,bank_id,"+"account_type,balance)values(?,?,?,?)";
		try(Connection con=DBConnection.getConnection();PreparedStatement ps=con.prepareStatement(sql)){
			ps.setInt(1, account.getCustomerId());
			ps.setInt(2, account.getBank().getBank_id());
			ps.setString(3, account.getAccountType());
			ps.setDouble(4, account.getBalance());
			int result= ps.executeUpdate();
			if(result==0) {
				throw new InvalidAccountTypeException(""+"Account type not recognized");
				
			}	
		}
	}
	
	@Override
	public void updateAccount(Account account) throws SQLException, InvalidAccountTypeException {
		String updateQuery="update Account set bank_id=?,account_type=?,balance=? where customer_id=?";
		try(Connection con=DBConnection.getConnection();PreparedStatement ps=con.prepareStatement(updateQuery)){
			ps.setInt(1,account.getAccountId());
			ps.setInt(1, account.getCustomerId());
			ps.setInt(2, account.getBank().getBank_id());
			ps.setString(3,account.getAccountType());
			ps.setDouble(4,account.getBalance());
			int updateresult=ps.executeUpdate();
			if(updateresult>0) {
				System.out.println("Upadated Successfully");	
			}
		}	
	}

	@Override
	public boolean deleteAccount(int accountId) throws SQLException {
	    System.out.println("Attempting to delete account with account_id: " + accountId);
	    String deleteQuery = "DELETE FROM Account WHERE account_id=?";
	    try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteQuery)) {
	        ps.setInt(1, accountId);
	        int delres = ps.executeUpdate();
	        System.out.println("Delete result: " + delres);
	        return delres > 0;
	    }
	}

	public void viewAccount(int accountId) throws SQLException, AccountnotFoundException {
		String sql="select * from account where account_id = ?";
		try(Connection con = DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql))
		{
			ps.setInt(1, accountId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Account ID: "+rs.getString("account_id")+"\n");
				System.out.println("Customer ID: "+rs.getString("customer_id")+"\n");
				System.out.println("Bank ID: "+rs.getString("bank_id")+"\n");
				System.out.println("Account Type: "+rs.getString("account_type")+"\n");
				System.out.println("Balance: "+rs.getString("balance")+"\n");
				
			}
			else {
				throw new AccountnotFoundException(""+"Account ID Invalid");
			}
		}	
	}

	
	
}
