package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exception.BankingException;
import model.Bank;
import utility.DBConnection;

public class BankDAOImpl implements BankDAO{

	@Override
	public Bank getBankById(int bankId) throws SQLException, BankingException {
		String query="SELECT * FROM Bank WHERE bank_id=?";
		try(Connection conn=DBConnection.getConnection();PreparedStatement stmt=conn.prepareStatement(query)){
			stmt.setInt(1,bankId);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				return new Bank(bankId, rs.getString("bank_name"),rs.getString("bank_branch"));
			}
			throw new BankingException("Bank not found for ID: "+bankId);
		}
		
	}

}
