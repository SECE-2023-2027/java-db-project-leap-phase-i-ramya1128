package dao;

import java.sql.SQLException;

import exception.InvalidTransactionAmountException;
import exception.TransactionFailureException;

public interface TransactionDAO {
	void deposit(int accountId,double ammount) throws InvalidTransactionAmountException, TransactionFailureException ;
	void withdraw(int accountId,double ammount) throws TransactionFailureException, InvalidTransactionAmountException, SQLException;
	void transferFunds(int fromAccount,int toAccount, double amount);

}
